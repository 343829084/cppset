/* Test STT_GNU_IFUNC symbols with PIE.  */

#include "ifuncmain1.c"
