extern void b_function (void);
extern void c_function (void);

void
b_function (void)
{
  c_function();
}
